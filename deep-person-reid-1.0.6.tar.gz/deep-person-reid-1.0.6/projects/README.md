Here are some projects that are built on Torchreid.
